﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Controles_de_Javier_Moleon
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            LoadCharacters();
            LoadModules();
        }

        // Clase para representar personajes
        public class Character
        {
            public string Name { get; set; }
            public string ImagePath { get; set; }
        }

        // Clase para representar módulos
        public class Module
        {
            public string Name { get; set; }
            public int Progress { get; set; }
            public SolidColorBrush Color { get; set; }
        }

        // Cargar personajes en el ComboBox
        private void LoadCharacters()
        {
            var characters = new List<Character>
            {
                new Character { Name = "Mario", ImagePath = "Images/mario.png" },
                new Character { Name = "Link", ImagePath = "Images/link.png" },
                new Character { Name = "Sonic", ImagePath = "Images/sonic.png" }
            };

            comboBox.ItemsSource = characters;
        }

        // Cargar módulos en el ListBox
        private void LoadModules()
        {
            var modules = new List<Module>
            {
                new Module { Name = "Sistemas de Gestión Empresarial", Progress = 80, Color = Brushes.Black },
                new Module { Name = "Desarrollo de Interfaces", Progress = 60, Color = Brushes.Black },
                new Module { Name = "Interfaces de Usuario", Progress = 90, Color = Brushes.Black },
                new Module { Name = "Programación Multimedia y Dispositivos Móviles", Progress = 40, Color = Brushes.Red } // Módulo menos gustado
            };

            listBox.ItemsSource = modules;
        }
    }
}