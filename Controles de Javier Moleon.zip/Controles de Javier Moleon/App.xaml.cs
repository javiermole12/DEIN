﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace Controles_de_Javier_Moleon
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
